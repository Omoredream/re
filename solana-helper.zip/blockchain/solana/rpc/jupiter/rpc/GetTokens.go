package rpc

import (
	"net/http"

	"github.com/gogf/gf/v2/encoding/gjson"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"

	"git.wkr.moe/web3/solana-helper/errcode"

	jupiterTypes "git.wkr.moe/web3/solana-helper/blockchain/solana/rpc/jupiter/types"
)

type GetTokensResponse []string

func (node *RPC) GetTokens(ctx g.Ctx) (tokens []string, err error) {
	step := "获取可交易代币"
	resp, err := node.client.R().
		Get("/tokens")
	if err != nil {
		err = gerror.Wrapf(err, "发送%s请求失败", step)
		return
	}

	if resp.StatusCode != http.StatusOK {
		if resp.StatusCode == http.StatusBadRequest {
			var result jupiterTypes.ErrorResponse
			err = gjson.DecodeTo(resp.Bytes(), &result)
			if err != nil {
				err = gerror.Wrapf(err, "解析%s响应失败", step)
				return
			}

			if result.ErrorCode != "" {
				err = gerror.NewCode(result.ErrorCode)
			} else if result.ErrorCodeOld != "" {
				err = gerror.NewCode(result.ErrorCodeOld)
			} else {
				err = gerror.New(resp.String())
			}
			err = gerror.Wrap(err, result.Error)
			switch gerror.Code(err) {
			case jupiterTypes.NotSupported,
				jupiterTypes.CircularArbitrageIsDisabled,
				jupiterTypes.NoRoutesFound,
				jupiterTypes.CouldNotFindAnyRoute,
				jupiterTypes.TokenNotTradable,
				jupiterTypes.RoutePlanDoesNotConsumeAllTheAmount:
				err = gerror.WrapCode(errcode.FatalError, err)
			}
		} else {
			err = gerror.Newf("HTTP %d, %s", resp.StatusCode, resp.Status)
		}
		err = gerror.Wrapf(err, "服务器响应%s请求失败", step)
		return
	}

	var result GetTokensResponse
	err = gjson.DecodeTo(resp.Bytes(), &result)
	if err != nil {
		err = gerror.Wrapf(err, "解析%s响应失败", step)
		return
	}

	tokens = result

	return
}
